# Usage: .\deploy.ps1 -keyVaultName "kv-nom" [-location "francecentral"]

param (
    [Parameter(Mandatory=$true)]
    [string]$keyVaultName,

    [Parameter(Mandatory=$false)]
    [string]$location = "francecentral"
)

$rgName = "rg-lab-bicep-student"
$timestamp = Get-Date -Format "yyyyMMddHHmmss"

Write-Host "--- Début du déploiement ---" -ForegroundColor Cyan

# 1. Vérification/Création du Groupe de Ressources
Write-Host "Vérification du groupe de ressources $rgName..."
az group create --name $rgName --location $location --output none

# 2. Validation (What-If)
Write-Host "Exécution de la prévisualisation (What-If)..."
az deployment group what-if `
    --resource-group $rgName `
    --parameters main.bicepparam

# 3. Déploiement
Write-Host "Lancement du déploiement..."
az deployment group create `
    --name "LabDeployment-$timestamp" `
    --resource-group $rgName `
    --parameters main.bicepparam

Write-Host "--- Déploiement terminé avec succès ---" -ForegroundColor Green
