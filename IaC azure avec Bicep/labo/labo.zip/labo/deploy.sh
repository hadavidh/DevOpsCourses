#!/bin/bash
# Usage: ./deploy.sh <NOM_DU_KEYVAULT> [LOCATION]

KV_NAME=$1
LOCATION=${2:-"francecentral"}
RG_NAME=""

if [ -z "$KV_NAME" ]; then
    echo "Erreur: Le nom du Key Vault est requis."
    echo "Usage: ./deploy.sh <NOM_DU_KEYVAULT> [LOCATION]"
    exit 1
fi

echo "--- Début du déploiement ---"

# 1. Vérification/Création du Groupe de Ressources
echo "Vérification du groupe de ressources $RG_NAME..."
az group create --name $RG_NAME --location $LOCATION --output none

# 2. Validation (What-If)
echo "Exécution de la prévisualisation (What-If)..."
az deployment group what-if \
    --resource-group $RG_NAME \
    --parameters main.bicepparam

# 3. Déploiement
echo "Lancement du déploiement..."
az deployment group create \
    --name "LabDeployment-$(date +%Y%m%d%H%M%S)" \
    --resource-group $RG_NAME \
    --parameters main.bicepparam

echo "--- Déploiement terminé avec succès ---"
