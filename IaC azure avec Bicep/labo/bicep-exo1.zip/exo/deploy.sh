az group create --name RG-Architecture-MultiRegion --location westeurope

az deployment group create \
  --resource-group RG-Architecture-MultiRegion \
  --template-file main.bicep \
  --parameters main.bicepparam